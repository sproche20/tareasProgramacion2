/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencias;

import java.util.Date;

/**
 *
 * @author P.Roche
 */
public class herencia {
/**
* @param args the command line * @param args the command line arguments arguments
*/
public static void main(String[] args) {
// TODO code application logic here
Empleado empleado1=new Empleado("Juan", 5000.0);
    System.out.println("Empleado= "+empleado1);
    Cliente cliente1=new Cliente(new Date(),true,"karla",'F',28,"saturno15");
    System.out.println("cliente1= "+cliente1);
}

}
