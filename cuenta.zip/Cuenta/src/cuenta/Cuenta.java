/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cuenta;

/**
 *
 * @author P.Roche
 */
public class Cuenta {
    private int numero;
    private String tipo;
    private double saldo;
public void mostrarCuenta()
{
    System.out.println("Cuenta N°: "+this.numero+" ||Tipo: "+this.tipo+" ||saldo: $"+this.saldo);  
}
public Cuenta()
{
    this.numero=100;
    this.tipo="a";
    this.saldo=50;
}
public Cuenta(int numero, String tipo, double saldo)
{
    this.numero=numero;
    this.tipo=tipo;
    this.saldo=saldo;
}
}
