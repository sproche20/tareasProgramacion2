/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cuenta;

import java.util.Scanner;

/**
 *
 * @author P.Roche
 */
public class Principal {
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        System.out.println("Ingrese el numero de la cuenta");
        int numero=leer.nextInt();
        System.out.println("ingrese el tipo de cuenta");
        String tipo=leer.next();
        System.out.println("Ingrese el saldo de la cuenta");
        double saldo=leer.nextFloat();
        Cuenta c;
        c=new Cuenta();
        Cuenta c2=new Cuenta(numero,tipo,saldo);
        c2.mostrarCuenta();
        c.mostrarCuenta();
    }
}
